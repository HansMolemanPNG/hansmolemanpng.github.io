# Informatica Multidomain MDM XXE Research

## Overview

During security research, an XXE vulnerability was identified in the Business Entity Services API.

## Root Cause

The endpoint accepted XML payloads even when designed for JSON requests.

## Impact

- Blind XXE
- Local file probing
- Potential SSRF

## Timeline

- Dec 2025 – Vulnerability reported
- Feb 2026 – HF5 released
- Mar 2026 – Fix moved to HF6